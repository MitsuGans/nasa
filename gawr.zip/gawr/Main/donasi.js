const donasi = (prefix) => {
	return `Gawrr
          
*DONASI*
*PULSA : 0852-4075-0713`
}

exports.donasi = donasi
