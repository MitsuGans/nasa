const donasi = () => {
	return `*SAGIRI BOT*	

  Hi👋️
  
          *FITUR*
          
┏━━━°❀ ❬ 𝘼𝘽𝙊𝙐𝙏 ❭ ❀°━━━┓
┃
┏❉ *#info*
┣❉ *#Donasi* 
┗❉ *#creator* 
┃
┣━━━°❀ ❬ 𝗗𝗢𝗡𝗔𝗦𝗜 ❭ ❀°━━━⊱
┃
┣➥ *GOPAY:* 0821-2598-6924
┣➥ *PULSA:* 0821-2598-6924
┣➥ *OVO:* 0821-2598-6924
┃
┣━━━━━━━━━━━━━━━━━━━━`
}

exports.donasi = donasi
