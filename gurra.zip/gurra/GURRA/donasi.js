const donasi = (prefix) => {
	return `*Gawrr Gurra*
          
*DONASI*
*PULSA* : 085240750713`
}

exports.donasi = donasi
