
const help = (prefix) => { 
	return `            	
——————————————「♥」
、。 *${prefix}owner*
、。 *${prefix}donasi*
、。 *${prefix}info*
——————————————「♥」
、。 *${prefix}sticker*
、。 *${prefix}sticker nobg*
、。 *${prefix}tsticker*
、。 *${prefix}nulis*
、。 *${prefix}logowolf*
、。 *${prefix}tts*
、。 *${prefix}tiktok*
、。 *${prefix}meme*
、。 *${prefix}memeindo*
、。 *${prefix}nsfwloli* 
、。 *${prefix}ocr*
、。 *${prefix}neko*
、。 *${prefix}randomanime*
、。 *${prefix}loli*
、。 *${prefix}waifu*
、。 *${prefix}ytmp3*
、。 *${prefix}ytmp4*
——————————————「♥」
、。 *${prefix}add* [62xxx]
、。 *${prefix}kick* [tag]
、。 *${prefix}setpp*
、。 *${prefix}tagme*
、。 *${prefix}demote* [tag]
、。 *${prefix}promote* [tag]
、。 *${prefix}grup* [buka/tutup]
、。 *${prefix}welcome* [1/0]
、。 *${prefix}nsfw* [1/0]
、。 *${prefix}simih* [1/0]
——————————————「♥」
、。 *${prefix}bc* 
、。 *${prefix}clearall*
、。 *${prefix}setprefix*
、。 *${prefix}leave*
、。 *${prefix}clone* [tag]
——————————————「♥」
、。 *${prefix}spamsms*
、。 *${prefix}spamcall*
、。 *${prefix}spamgmail*
——————————————「♥」
、。 *${prefix}ytsearch*
、。 *${prefix}listadmin*
、。 *${prefix}blocklist*
、。 *${prefix}wait*
、。 *${prefix}nama*
、。 *${prefix}map*
、。 *${prefix}qrcode*
、。 *${prefix}tiktokstalk*
、。 *${prefix}shortlink*
、。 *${prefix}url2img*
、。 *${prefix}alay*
、。 *${prefix}quotes*
、。 *${prefix}bucin*
、。 *${prefix}wiki*
、。 *${prefix}wikien*
、。 *${prefix}tapi*
——————————————「♥」`
}

exports.help = help

 